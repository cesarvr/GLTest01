//
//  ER9PolyTestUno.h
//  GLTest01
//
//  Created by Cesar Luis Valdez on 05/03/13.
//  Copyright (c) 2013 Cesar Luis Valdez. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ER9PolyTestUno : NSObject

@property int indice_size;
@property (nonatomic) GLuint vector_buffer, indices_buffer;

@end
